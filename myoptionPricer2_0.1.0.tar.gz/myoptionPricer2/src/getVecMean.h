#ifndef GETVECMEAN_H
#define GETVECMEAN_H

double getVecMean(std::vector<double> thisVec);

#endif
