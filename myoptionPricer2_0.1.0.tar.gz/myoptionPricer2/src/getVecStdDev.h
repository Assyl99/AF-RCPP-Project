#ifndef GETVECSTDDEV_H
#define GETVECSTDDEV_H

double getVecStdDev (std::vector<double> thisVec);

#endif
